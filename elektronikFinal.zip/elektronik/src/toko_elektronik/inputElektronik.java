/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package toko_elektronik;
import com.onbarcode.barcode.IBarcode;
import com.onbarcode.barcode.EAN13;
import java.awt.Font;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.Random;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class inputElektronik extends javax.swing.JFrame {

    /**
     * Creates new form inputElektronik
     */
    public inputElektronik() {
     initComponents();
         this.setResizable(false);
        getDataComboBox();
         load_table();
         kosong();
        
    }
private void load_table(){
    DefaultTableModel model = new DefaultTableModel();
       model.addColumn("No");
       model.addColumn("Id Barang");
       model.addColumn("Nama Barang");
       model.addColumn("Harga Beli");
       model.addColumn("Harga Jual");
       model.addColumn("Jumlah");
       model.addColumn("Kode Barcode");
     try{
         
         int no = 1;
         String sql = "SELECT * FROM `data_barang`";
         java.sql.Connection conn = (Connection) konektor.configDB();
         java.sql.Statement stm = conn.createStatement();
         java.sql.ResultSet rs = stm.executeQuery(sql);
         while(rs.next()){
             model.addRow(new Object[]{
                 no++,rs.getString(1),rs.getString(3),
                 rs.getString(4),rs.getString(5),
                 rs.getString(6),rs.getString(9),
                 
             });
         }
         jTable1.setModel(model);
     } catch(Exception e){
         
     }
}
public static String getRandomNumberString()   {
 Random rnd = new Random();
 int number = rnd.nextInt(999999999);
 return  String.format("%012d", number);
 
 
}

private void generate(String kode) throws Exception {
    EAN13 barcode = new EAN13();
    
    barcode.setData(kode);
    
    barcode.setUom(IBarcode.UOM_PIXEL);
    
    barcode.setX(3f);
    
    barcode.setY(75f);
    
    barcode.setLeftMargin(0f);
    barcode.setRightMargin(0f);
    barcode.setTopMargin(0f);
    barcode.setBottomMargin(0f);
    
    barcode.setResolution(72);
    
    barcode.setShowText(true);
    
    barcode.setTextFont(new Font("Arial", 0, 12));
    
    barcode.setTextMargin(6);
    
    
    barcode.setRotate(IBarcode.ROTATE_0);
    
    barcode.drawBarcode("src" + "/" + "img" + "/barcode/" + kode + ".gif");
    
    
    
    
    
}
private void  kosong(){
    idbarang.enable();
    namabarang.setText(null);
    harga_beli.setText(null);
    hargajual.setText(null);
    jumlah.setText(null);
    jComboBox1.setSelectedItem(this); 
   // barcode.setIcon();
}
 public void getDataComboBox(){
        
        String queryEtalaseItem = "SELECT  * FROM `jenis_etalase`";
        try{
        java.sql.Connection conn =(Connection )konektor.configDB();
        java.sql.PreparedStatement pst = conn.prepareStatement(queryEtalaseItem);
           java.sql.ResultSet rs = pst.executeQuery(queryEtalaseItem);
           while(rs.next()){
               jComboBox1.addItem(rs.getString("jenis_etalase"));
           }
        }catch(Exception e){
            
        }        
    }
  static int posisiIndexBarang(){
            ArrayList<String> datIndex = new ArrayList<>();
         
        try{
            String sqlQuery = "SELECT * FROM `data_barang` ORDER BY `indexNo` DESC";
            java.sql.Connection conn = (Connection) konektor.configDB();
            java.sql.PreparedStatement prs = conn.prepareStatement(sqlQuery);
            java.sql.ResultSet rs = prs.executeQuery();
        
              while(rs.next()){
                  datIndex.add(rs.getString("IndexNo"));
             }
             
        } catch(Exception e){
            e.printStackTrace();
        }
        
        
        return Integer.parseInt(datIndex.get(0));
    }
      static int posisiIndexTransaksi(){
            ArrayList<String> dataIndexTransaksi = new ArrayList<>();
         
        try{
            String sqlQuery = "SELECT * FROM `data_barang` ORDER BY `indexNo` DESC";
            java.sql.Connection conn = (Connection) konektor.configDB();
            java.sql.PreparedStatement prs = conn.prepareStatement(sqlQuery);
            java.sql.ResultSet rs = prs.executeQuery();
        
              while(rs.next()){
                  dataIndexTransaksi.add(rs.getString("IndexNo"));
             }
             
        } catch(Exception e){
            e.printStackTrace();
        }
        
        return Integer.parseInt(dataIndexTransaksi.get(0));
    }
    
       static int getPosisiDataBarang(){
            ArrayList<String> data = new ArrayList<>();
         
        try{
            String sqlQuery = "SELECT * FROM `data_barang` ORDER BY `indexNo` DESC";
            java.sql.Connection conn = (Connection) konektor.configDB();
            java.sql.PreparedStatement prs = conn.prepareStatement(sqlQuery);
            java.sql.ResultSet rs = prs.executeQuery();
        
              while(rs.next()){
                  data.add(rs.getString("idbarang"));
             }
             
        } catch(Exception e){
            e.printStackTrace();
        }
        String teksDataBarang = data.get(0).replaceAll("TB", "");
        
        return Integer.parseInt(teksDataBarang);
    }

    
    static int getPosisiTransaksiAkhir(){
            ArrayList<String> dataTF = new ArrayList<>();
         
        try{
            String sqlQuery = "SELECT * FROM `transaksi_beli` ORDER BY `indexNo` DESC";
            java.sql.Connection conn = (Connection) konektor.configDB();
            java.sql.PreparedStatement prs = conn.prepareStatement(sqlQuery);
            java.sql.ResultSet rs = prs.executeQuery();
        
              while(rs.next()){
                  dataTF.add(rs.getString("id_transaksibeli"));
                  
             }
             
        } catch(Exception e){
            e.printStackTrace();
        }
        String teksTransaksiAkhir =dataTF.get(0).replaceAll("TF", "");
        
        return Integer.parseInt(teksTransaksiAkhir);
    }

     static int c(){
         return 1;
     } 
     int posisiTerakhir = getPosisiTransaksiAkhir();
     int indexDataBarang = posisiIndexBarang() + 1;
     int indexTransaksi = posisiIndexTransaksi() + 1;
     int posisiDataBarang = getPosisiDataBarang() + 1 ;
     int posisiDataTransaksi = getPosisiTransaksiAkhir() + 1;
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jumlah = new javax.swing.JTextField();
        namabarang = new javax.swing.JTextField();
        hargajual = new javax.swing.JTextField();
        harga_beli = new javax.swing.JTextField();
        jComboBox1 = new javax.swing.JComboBox<>();
        input = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        clear1 = new javax.swing.JButton();
        randomnumber = new javax.swing.JButton();
        barcode = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        jButton7 = new javax.swing.JButton();
        jButton8 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        idbarang = new javax.swing.JTextField();
        kd_barang = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jumlah.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jumlahActionPerformed(evt);
            }
        });
        getContentPane().add(jumlah, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 360, 240, -1));

        namabarang.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                namabarangActionPerformed(evt);
            }
        });
        getContentPane().add(namabarang, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 250, 240, -1));

        hargajual.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                hargajualActionPerformed(evt);
            }
        });
        getContentPane().add(hargajual, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 290, 240, -1));

        harga_beli.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                harga_beliActionPerformed(evt);
            }
        });
        getContentPane().add(harga_beli, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 330, 240, -1));

        jComboBox1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox1ActionPerformed(evt);
            }
        });
        getContentPane().add(jComboBox1, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 400, 240, -1));

        input.setOpaque(false);
        input.setContentAreaFilled(false);
        input.setBorderPainted(false);
        input.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inputActionPerformed(evt);
            }
        });
        getContentPane().add(input, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 280, 110, 40));

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTable1);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 460, 886, 200));

        jButton2.setOpaque(false);
        jButton2.setContentAreaFilled(false);
        jButton2.setBorderPainted(false);
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 320, 110, 40));

        jButton3.setOpaque(false);
        jButton3.setContentAreaFilled(false);
        jButton3.setBorderPainted(false);
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 360, 110, 40));

        clear1.setOpaque(false);
        clear1.setContentAreaFilled(false);
        clear1.setBorderPainted(false);
        clear1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                clear1ActionPerformed(evt);
            }
        });
        getContentPane().add(clear1, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 400, 110, 40));

        randomnumber.setOpaque(false);
        randomnumber.setContentAreaFilled(false);
        randomnumber.setBorderPainted(false);
        randomnumber.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                randomnumberActionPerformed(evt);
            }
        });
        getContentPane().add(randomnumber, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 240, 110, 40));
        getContentPane().add(barcode, new org.netbeans.lib.awtextra.AbsoluteConstraints(910, 260, 180, 80));

        jButton1.setOpaque(false);
        jButton1.setContentAreaFilled(false);
        jButton1.setBorderPainted(false);
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 670, 150, 40));

        jButton4.setOpaque(false);
        jButton4.setContentAreaFilled(false);
        jButton4.setBorderPainted(false);
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton4, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 160, 170, 70));

        jButton5.setOpaque(false);
        jButton5.setContentAreaFilled(false);
        jButton5.setBorderPainted(false);
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton5, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 330, 190, 50));

        jButton6.setOpaque(false);
        jButton6.setContentAreaFilled(false);
        jButton6.setBorderPainted(false);
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton6, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 390, 190, 50));

        jButton7.setOpaque(false);
        jButton7.setContentAreaFilled(false);
        jButton7.setBorderPainted(false);
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton7, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 450, 190, 50));

        jButton8.setOpaque(false);
        jButton8.setContentAreaFilled(false);
        jButton8.setBorderPainted(false);
        jButton8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton8ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton8, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 510, 190, 50));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gambar_layout/input barang.png"))); // NOI18N
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1140, 710));
        getContentPane().add(idbarang, new org.netbeans.lib.awtextra.AbsoluteConstraints(586, 190, 60, -1));

        kd_barang.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                kd_barangActionPerformed(evt);
            }
        });
        getContentPane().add(kd_barang, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 170, 90, 40));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jumlahActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jumlahActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jumlahActionPerformed

    private void hargajualActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_hargajualActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_hargajualActionPerformed

    private void harga_beliActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_harga_beliActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_harga_beliActionPerformed

    private void inputActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inputActionPerformed
        String kb = String.valueOf(kd_barang.getText());
        JOptionPane.showMessageDialog(null, "Input Data Berhasil");
        load_table();
        try {
String sqlx = "INSERT INTO `data_barang`(`idbarang`,`idetalase`,`namabarang`,`hargabeli`,`hargajual`,`stock` "+ ",`tanggal`,`indexno`,`kd_barcode` ) "
        + "VALUES('TB" + posisiDataBarang + "'," +jComboBox1.getSelectedIndex() +",'"+ namabarang.getText() +"'," + harga_beli.getText()  +
"," + hargajual.getText() +"," +jumlah.getText() + ", NOW(),'" + indexDataBarang +"','"+kd_barang.getText()+"');";
    
String queryInsertTransaksi = "INSERT INTO `transaksi_beli`(`id_transaksibeli`,`idBarang`,`indexno`) VALUES"
        + "('TF" + posisiDataTransaksi + "','TB" + posisiDataBarang +"','" +indexTransaksi+"');"; 

             java.sql.Connection conn = (Connection)konektor.configDB();
             java.sql.PreparedStatement pst1=conn.prepareStatement(sqlx);
            pst1.execute();
             java.sql.Connection con = (Connection) konektor.configDB();
             java.sql.PreparedStatement prc = con.prepareStatement(queryInsertTransaksi);
             prc.execute();             
         indexDataBarang ++;
         indexTransaksi++;
         posisiDataBarang ++;
         posisiDataTransaksi ++;
           generate(kb);
     } catch (Exception e) {
         JOptionPane.showMessageDialog(this, e.getMessage());            
         
     }
      
          load_table();
          kosong();
          
       
    }//GEN-LAST:event_inputActionPerformed

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
  int baris = jTable1.rowAtPoint(evt.getPoint());
 
        if(jTable1.getValueAt(baris, 2) == null){
            namabarang.setText("");
        } else{
            namabarang.setText(jTable1.getValueAt(baris, 2).toString());
        }
        if(jTable1.getValueAt(baris,3) == null){
            harga_beli.setText("");
        } else{
            harga_beli.setText(jTable1.getValueAt(baris,3).toString());
        }        
        if(jTable1.getValueAt(baris, 4) == null){
            hargajual.setText("");
        } else{
            hargajual.setText(jTable1.getValueAt(baris,4).toString());
        }
        if(jTable1.getValueAt(baris, 5) == null){
            jumlah.setText("");
        } else{
            jumlah.setText(jTable1.getValueAt(baris, 5).toString());
        }
        if(jTable1.getValueAt(baris, 1) == null){
            idbarang.setText("");
        } else{
            idbarang.setText(jTable1.getValueAt(baris, 1).toString());
        }
        if(jTable1.getValueAt(baris, 6) == null){
            barcode.setText("");
        } else{
           String kb2 = jTable1.getValueAt(baris, 6).toString();
            ImageIcon imgThisimg = new ImageIcon("src" + "/" + "img" + "/barcode/" + kb2 + ".gif");
            barcode.setIcon(imgThisimg);
        }
     
        
        
    }//GEN-LAST:event_jTable1MouseClicked

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
     try {
           String sql = "UPDATE `data_barang`"
                   + "SET NamaBarang = '"+namabarang.getText()
                   +"',HargaBeli= '"+harga_beli.getText()
                   +"',HargaJual= '"+hargajual.getText()
                   +"',stock= '"+jumlah.getText()
                   +"'WHERE data_barang.idBarang= '"+idbarang.getText()
                   +"'";
           java.sql.Connection conn=(Connection)konektor.configDB();
           java.sql.PreparedStatement pat=conn.prepareStatement(sql);
           pat.execute();
           JOptionPane.showMessageDialog(null, "data berhasil di edit");
       }catch (Exception e){
           JOptionPane.showMessageDialog(null, "Perubahan Data Gagal"
           +e.getMessage());
       }
       load_table();
       kosong();
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
       try{
        String sql = "DELETE FROM `transaksi_beli` WHERE `idBarang` = '" + idbarang.getText().toString() +"';";
        String sql1 =  "DELETE FROM `data_barang` WHERE `idBarang` = '" + idbarang.getText().toString() +"';";
        String sql1l =  "DELETE FROM `detail_transaksi` WHERE `idbarang` = '" + idbarang.getText().toString() +"';";
        java.sql.Connection conn = (Connection) konektor.configDB();
           java.sql.Connection conn1 = (Connection) konektor.configDB();
              java.sql.Connection conn2 = (Connection) konektor.configDB();
        java.sql.Statement smt_1 = conn.createStatement();
        java.sql.Statement smt_2 = conn1.createStatement();
        java.sql.Statement smt_3 = conn2.createStatement();
        smt_1.execute(sql);
        smt_3.execute(sql1l);
        smt_2.execute(sql1);
      
        JOptionPane.showMessageDialog(null, "berhasil di hapus");
        } catch(Exception e){
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
        load_table();
        kosong();
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jComboBox1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox1ActionPerformed

    private void clear1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_clear1ActionPerformed
    kosong();
    }//GEN-LAST:event_clear1ActionPerformed

    private void randomnumberActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_randomnumberActionPerformed
       kd_barang.setText(getRandomNumberString());
       jumlah.setText("");
       harga_beli.setText("");
       hargajual.setText("");
       kd_barang.enable(false);
       load_table();
       
    }//GEN-LAST:event_randomnumberActionPerformed

    private void kd_barangActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_kd_barangActionPerformed
    
    }//GEN-LAST:event_kd_barangActionPerformed

    private void namabarangActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_namabarangActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_namabarangActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
this.setVisible(false);
                 new  welcome().setVisible(true);        // TODO add your handling code here:
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
this.setVisible(false);
                 new  transaksiPenjualan().setVisible(true);        // TODO add your handling code here:
    }//GEN-LAST:event_jButton6ActionPerformed

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
this.setVisible(false);
                 new  laporan_pemasukan().setVisible(true);        // TODO add your handling code here:
    }//GEN-LAST:event_jButton7ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
this.setVisible(false);
                 new  menu_utama().setVisible(true);        // TODO add your handling code here:
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
this.setVisible(false);
                 new  detail_stock().setVisible(true);        // TODO add your handling code here:
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton8ActionPerformed
this.setVisible(false);
                 new  CPAdmin().setVisible(true);        // TODO add your handling code here:
    }//GEN-LAST:event_jButton8ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(inputElektronik.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(inputElektronik.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(inputElektronik.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(inputElektronik.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new inputElektronik().setVisible(true);
            }
        });
    }
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel barcode;
    private javax.swing.JButton clear1;
    private javax.swing.JTextField harga_beli;
    private javax.swing.JTextField hargajual;
    private javax.swing.JTextField idbarang;
    private javax.swing.JButton input;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton8;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField jumlah;
    private javax.swing.JTextField kd_barang;
    private javax.swing.JTextField namabarang;
    private javax.swing.JButton randomnumber;
    // End of variables declaration//GEN-END:variables
}
 
