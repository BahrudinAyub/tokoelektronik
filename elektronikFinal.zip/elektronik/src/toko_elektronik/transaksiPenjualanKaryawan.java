/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package toko_elektronik;

/**
 *
 * @author User
 */
import static com.a.a.a.k.e;
import java.sql.*;
import java.sql.ResultSet;
import java.awt.*;
import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.design.JRDesignQuery;
import net.sf.jasperreports.engine.design.JasperDesign;
import net.sf.jasperreports.engine.util.JRLoader;
import net.sf.jasperreports.engine.xml.JRXmlLoader;
import net.sf.jasperreports.view.JasperViewer;
class dataModelPenjualan1{
    private int idPenjualan;
    private String idbarang;
    private String harga;
    private String jumlah;

    public dataModelPenjualan1(int idPenjualan, String idbarang, String harga, String jumlah) {
        this.idPenjualan = idPenjualan;
        this.idbarang = idbarang;
        this.harga = harga;
        this.jumlah = jumlah;
    }

    public int getIdPenjualan() {
        return idPenjualan;
    }

    public String getIdbarang() {
        return idbarang;
    }

    public String getHarga() {
        return harga;
    }

    public String getJumlah() {
        return jumlah;
    }
}
public class transaksiPenjualanKaryawan extends javax.swing.JFrame {

    /**
     * Creates new form transaksiPenjualan
     */
    public transaksiPenjualanKaryawan() {
        initComponents();      
        this.setResizable(false);
        
        cariProduk objProduk = new cariProduk();
        objProduk.TampilData();
       // load_table();
        autonumber();
        set_model();
        
    }
    
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        txt_cari = new javax.swing.JTextField();
        namabarang = new javax.swing.JTextField();
        harga = new javax.swing.JTextField();
        jumlah = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jScrollPane2 = new javax.swing.JScrollPane();
        table = new javax.swing.JTable();
        totalbeli = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jButton8 = new javax.swing.JButton();
        jButton10 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        idtransaksi = new javax.swing.JTextField();
        idbarang = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        txt_cari.setBorder(null);
        txt_cari.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txt_cariKeyReleased(evt);
            }
        });
        getContentPane().add(txt_cari, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 245, 260, -1));
        getContentPane().add(namabarang, new org.netbeans.lib.awtextra.AbsoluteConstraints(880, 220, 210, -1));
        getContentPane().add(harga, new org.netbeans.lib.awtextra.AbsoluteConstraints(880, 250, 210, -1));
        getContentPane().add(jumlah, new org.netbeans.lib.awtextra.AbsoluteConstraints(880, 280, 210, -1));

        jButton1.setOpaque(false);
        jButton1.setContentAreaFilled(false);
        jButton1.setBorderPainted(false);
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(1000, 310, 100, 40));

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(712, 370, 380, 130));

        table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        table.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tableMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(table);

        getContentPane().add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 270, 420, 330));

        totalbeli.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        getContentPane().add(totalbeli, new org.netbeans.lib.awtextra.AbsoluteConstraints(790, 540, 210, 20));

        jButton2.setOpaque(false);
        jButton2.setContentAreaFilled(false);
        jButton2.setBorderPainted(false);
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(910, 580, 90, 30));

        jButton3.setOpaque(false);
        jButton3.setContentAreaFilled(false);
        jButton3.setBorderPainted(false);
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(820, 580, 90, 30));

        jButton4.setOpaque(false);
        jButton4.setContentAreaFilled(false);
        jButton4.setBorderPainted(false);
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton4, new org.netbeans.lib.awtextra.AbsoluteConstraints(1010, 580, 90, 40));

        jButton5.setOpaque(false);
        jButton5.setContentAreaFilled(false);
        jButton5.setBorderPainted(false);
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton5, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 160, 170, 70));

        jButton8.setOpaque(false);
        jButton8.setContentAreaFilled(false);
        jButton8.setBorderPainted(false);
        jButton8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton8ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton8, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 340, 200, 60));

        jButton10.setOpaque(false);
        jButton10.setContentAreaFilled(false);
        jButton10.setBorderPainted(false);
        jButton10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton10ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton10, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 660, 160, 60));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gambar_layout/transaksi penjualan Karyawan.png"))); // NOI18N
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1130, 710));

        idtransaksi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                idtransaksiActionPerformed(evt);
            }
        });
        getContentPane().add(idtransaksi, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 150, 90, -1));
        getContentPane().add(idbarang, new org.netbeans.lib.awtextra.AbsoluteConstraints(950, 160, 120, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
 
        jTable1.getModel();
   DefaultTableModel tbl = (DefaultTableModel) jTable1.getModel();
   int subtotal = Integer.parseInt(harga.getText())*Integer.parseInt(jumlah.getText());
   Object[] sembarang=new Object[]{jTable1.getRowCount()+1,idbarang.getText(),namabarang.getText(),harga.getText(),jumlah.getText(),subtotal};
   tbl.addRow(sembarang);
    }//GEN-LAST:event_jButton1ActionPerformed

    private void txt_cariKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_cariKeyReleased
 String key = txt_cari.getText();
    System.out.println(key);
        cariProduk objProd = new cariProduk();
    if (key!="") {
        objProd.cariData(key);
    } else {       
    }
    }//GEN-LAST:event_txt_cariKeyReleased

    private void tableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tableMouseClicked
     int baris = table.rowAtPoint(evt.getPoint());
        if(table.getValueAt(baris, 1) == null){
            namabarang.setText("");
        } else{
            namabarang.setText(table.getValueAt(baris, 1).toString());
        }   
        if(table.getValueAt(baris, 2) == null){
            harga.setText("");
        } else{
            harga.setText(table.getValueAt(baris, 2).toString());
        }   
        if(table.getValueAt(baris, 0) == null){
            idbarang.setText("");
        } else{
            idbarang.setText(table.getValueAt(baris, 0).toString());
        }
    }//GEN-LAST:event_tableMouseClicked

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
//         int jA = table.getSelectedRow();
//        listObj.remove(jA);

   DefaultTableModel tbl = (DefaultTableModel) jTable1.getModel();
for (int ii=0;ii<tbl.getRowCount();ii++){
                tbl.removeRow(ii);
                totalbeli.setText(null);
            }
//kosong();
//load_table();
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        try {
            int stockTersedia = getJumlahStock(idbarang.getText().toString());
//             
            if(Integer.parseInt(jumlah.getText()) > stockTersedia){
               JOptionPane.showMessageDialog(null, "Mohon Maaf Stock Anda Hanya Tersisa " + stockTersedia);
     }      else{
                
//               int hasilHitung = stockTersedia - Integer.parseInt(jumlah.getText().toString());
//               String UPDATE_STOCK = "UPDATE `data_barang` SET `stock` = stock -'" + jumlah + "' WHERE `idBarang` = '" +  idbarang +"'";
//               java.sql.Connection connn = (Connection)konektor.configDB();
//               java.sql.PreparedStatement pst1=connn.prepareStatement(UPDATE_STOCK);
//               pst1.execute();
            }
            
            int granTotal=0;
            for (int ii=0;ii<jTable1.getRowCount();ii++){
                 granTotal = Integer.parseInt(jTable1.getValueAt(ii, 5).toString())+granTotal;
            }
             
             String sql = "INSERT INTO `transjual`(`idtrans`,`tanggal_transaksi`,`total`) VALUES('"+
                     idtransaksi.getText()+"',now(),'"+granTotal+"');";
             java.sql.Connection conn = (Connection)konektor.configDB();
             java.sql.PreparedStatement pst11=conn.prepareStatement(sql);
             pst11.execute();
          
            
             for(int iii=0;iii<jTable1.getRowCount();iii++){
                 
                
                String jumlah1 = jTable1.getValueAt(iii,4).toString();
                String sub_total = jTable1.getValueAt(iii,5).toString();
                String id_barang = jTable1.getValueAt(iii,1).toString();
               
              
            String sqll = "INSERT INTO `detail_transaksi`(`Jumlah`,`Sub_total`,`idtrans`,`idbarang`) VALUES('"+
                        jumlah1+"','"+sub_total+"','"+idtransaksi.getText()+"','"+id_barang+"')";
             java.sql.Connection con = (Connection)konektor.configDB();
             java.sql.PreparedStatement pst111=con.prepareStatement(sqll);
             pst111.execute();
             
//                       
            //JOptionPane.showMessageDialog(null, "Transaksi Telah Berhasil ");
          
     
           totalbeli.setText(String.valueOf(granTotal));
//           jTable1.print();
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, e);JOptionPane.showMessageDialog(null, "Transaksi Telah Berhasil ");
        }
        //autonumber();
   
        
           
            
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
       try {
     
   HashMap parameter = new HashMap () ;
            parameter.put ("sembarang", idtransaksi.getText()) ;

            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost/toko_elektronik","root","");
            File file = new File 
            ("C:\\Users\\User\\OneDrive\\Documents\\NetBeansProjects\\elektronik\\src\\main\\beta.jasper") ;
            JasperReport jr = (JasperReport) JRLoader.loadObject(file);
    
            JasperPrint jp = JasperFillManager.fillReport(jr, parameter,con);
           
            JasperViewer.viewReport( jp, false);
            JasperViewer.setDefaultLookAndFeelDecorated(true);
            } catch (Exception e) {
             e.printStackTrace();
            }
       autonumber();
    }//GEN-LAST:event_jButton4ActionPerformed

    private void idtransaksiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_idtransaksiActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_idtransaksiActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
this.setVisible(false);
                 new  daskborKaryawan().setVisible(true);        // TODO add your handling code here:
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton8ActionPerformed
 this.setVisible(false);
                 new  CPKaryawan().setVisible(true);       // TODO add your handling code here:
    }//GEN-LAST:event_jButton8ActionPerformed

    private void jButton10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton10ActionPerformed
this.setVisible(false);
                 new  welcome().setVisible(true);        // TODO add your handling code here:
    }//GEN-LAST:event_jButton10ActionPerformed
    
public class cariProduk extends javax.swing.JFrame {
    DefaultTableModel tabModel;
    ResultSet RsProduk = null;
        
     private void TampilData() {
         try {
            Object[] judul_kolom = {"idBarang"};
            tabModel = new DefaultTableModel(null,judul_kolom);
            table.setModel(tabModel);
            Connection conn = (Connection)konektor.configDB();
            Statement stt = conn.createStatement();
            tabModel.getDataVector().removeAllElements();
            
            tabModel.addColumn("Nama_Barang");
            table.setModel(tabModel);
            Statement stt1 = conn.createStatement();
            tabModel.getDataVector().removeAllElements();
            
            tabModel.addColumn("Harga");
            table.setModel(tabModel);
            Statement stt11 = conn.createStatement();
            tabModel.getDataVector().removeAllElements();
            
            RsProduk=stt.executeQuery("SELECT  * from `data_barang `");  
            while(RsProduk.next()){
                Object[] data={
                    RsProduk.getString("NamaBarang"),
                    RsProduk.getString("Harga"),
                    };
               tabModel.addRow(data);
            }                
        } catch (Exception ex) {
        System.err.println(ex.getMessage());
        }
         }
private void cariData(String key){
    try{
            tabModel=new DefaultTableModel();
                 tabModel.addColumn("idBarang");
            tabModel.addColumn("Nama_barang");
                 tabModel.addColumn("Harga");
            table.setModel(tabModel);
            
        if(key != ""){
            Connection conn=(Connection)konektor.configDB();
            Statement stt=conn.createStatement();
            tabModel.getDataVector().removeAllElements();
            String query = "SELECT  * from data_barang WHERE NamaBarang LIKE '%"+key+"%' or kd_barcode LIKE '%"+key+"%'";
            
        
            RsProduk=stt.executeQuery(query); 
            // RsProduk=stt.executeQuery(query1);
            while(RsProduk.next()){
                Object[] data={
                    RsProduk.getString("idbarang"),
                    RsProduk.getString("namabarang"),
                RsProduk.getString("hargajual")};
               tabModel.addRow(data);
               table.setModel(tabModel);   
            }
            } else{
         Connection conn=(Connection)konektor.configDB();
            Statement stt=conn.createStatement();
            tabModel.getDataVector().removeAllElements();
            String query = "SELECT  * from data_barang WHERE NamaBarang LIKE '%"+key+"%'";
        
            RsProduk=stt.executeQuery(query);  
                Object[] data={
                    "kosong"
                    };
               tabModel.addRow(data);
            table.setModel(tabModel);   
        }               
        } catch (Exception ex) {
        System.err.println(ex.getMessage());
        }
    }
}

private  void set_model(){
    DefaultTableModel model = new DefaultTableModel();
       model.addColumn("No");
       model.addColumn("id Barang");
       model.addColumn("Nama Barang");
       model.addColumn("Harga Jual");
       model.addColumn("Jumlah");
       model.addColumn("Sub Total");
       
          jTable1.setModel(model);
}
private void load_table(){
    DefaultTableModel model = new DefaultTableModel();
       model.addColumn("No");
       model.addColumn("Nama Barang");
       model.addColumn("Harga Jual");
       model.addColumn("Jumlah");
       model.addColumn("Sub Total");
     try{
         
         for(int i = 0; i < listObj.size(); i++){
             
         model.addRow(new Object[]{
               listObj.get(i).getIdPenjualan(),
             listObj.get(i).getIdbarang(),
             listObj.get(i).getHarga(),
             listObj.get(i).getJumlah()
         });
         }
         jTable1.setModel(model);
     } catch(Exception e){
         
     }
}
static ArrayList<Integer> listNumber = new ArrayList<>();
static void posisiTerakhir(){
    try {
    String indexNo = "SELECT * FROM `penjualan` ORDER BY `idpenjualan` DESC";
    Connection omw = konektor.configDB();
    Statement stm = omw.createStatement();
    ResultSet rs = stm.executeQuery(indexNo);
    while(rs.next()){
        listNumber.add(Integer.parseInt(rs.getString("idpenjualan")));
    }
}
    catch(Exception e){
            e.printStackTrace();
            }
            
    
}
private void kosong() {
    namabarang.setText(null);
    harga.setText(null);
    jumlah.setText(null);
    totalbeli.setText(null);
    listObj.clear();
    load_table();
    autonumber();
}

static int total = 0;
static ArrayList<dataModelPenjualan>  listObj = new ArrayList<>();
static int nomer = 1;
public int getJumlahStock(String idBarang){
    String querySelect = "SELECT * FROM `data_Barang` WHERE `idBarang` = '" + idBarang +"'";
        try {
            java.sql.Connection con = (Connection) konektor.configDB();
            java.sql.PreparedStatement prp = con.prepareStatement(querySelect);
            java.sql.ResultSet rs = prp.executeQuery();
            while(rs.next()){
                return Integer.parseInt(rs.getString("stock"));
            }
        } catch (SQLException ex) {
            Logger.getLogger(transaksiPenjualanKaryawan.class.getName()).log(Level.SEVERE, null, ex);
        }
        return 0;
}
private void autonumber() {
       try {
           String sql = "SELECT MAX(idtrans) AS ID FROM transjual";
           java.sql.Connection conn = (Connection)konektor.configDB();
           java.sql.Statement pst = conn.createStatement();
           java.sql.ResultSet rs = pst.executeQuery(sql);
           while(rs.next()) {
               Object[] obj = new Object[1];
               obj[0] = rs.getString("ID");
               if(obj[0] == null) {
                   obj[0] = "TR000";
               }
               String str_kd = (String) obj[0];
               String kd = str_kd.substring(2, 5);
               int int_code = Integer.parseInt(kd);
               int_code++;
               String a = String.format("%03d", int_code);
               String b = "TR" + a;
               idtransaksi.setText(b);
               idtransaksi.setEditable(false);
           }
       } catch (Exception e) {      
       }
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(transaksiPenjualanKaryawan.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(transaksiPenjualanKaryawan.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(transaksiPenjualanKaryawan.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(transaksiPenjualanKaryawan.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new transaksiPenjualanKaryawan().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField harga;
    private javax.swing.JTextField idbarang;
    private javax.swing.JTextField idtransaksi;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton10;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton8;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField jumlah;
    private javax.swing.JTextField namabarang;
    private javax.swing.JTable table;
    private javax.swing.JLabel totalbeli;
    private javax.swing.JTextField txt_cari;
    // End of variables declaration//GEN-END:variables
}

